from cryptography.fernet import Fernet
print ("SCript is running...")
def encrypted_image():
    print("Starting encrption...")
    key = Fernet.generate_key()
    cipher = Fernet(key)
    with open("pic.jpg" , "rb") as f:
        data = f.read()
    encrypt_data = cipher.encrypt(data)
    with open ("encrypted_image.enc" , "wb") as f:
        f.write(encrypt_data)
    print("Image encrypted as 'encrypted_image.enc' . Save this key:" ,key.decode())
def decrypt_image():
    key = input("Enter the decryption key: ").encode()
    cipher = Fernet (key)
    with open ("encrypted_image.enc", "rb") as f: 
        encrypt_data= f.read()
    decrypted_data = cipher.decrypt(encrypt_data)
    with open("decrypted_pic.jpg" , "wb") as f : 
        f. write(decrypted_data)
    print("image decrypted as 'decrypted_pic.jpg'")
    print("waiting for user input...")
    choice = input("1 to Encrypt, 2 to Descrypt: ")
    if choice == "1":
        encrypt_image()
    elif choice == "2":
        decrypt_image()
    else: 
        print("Invalid choice!!!!")